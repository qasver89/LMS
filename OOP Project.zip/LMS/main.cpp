#include <QApplication>
#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>
#include <QFrame>
#include <QStackedWidget>
#include <QTableWidget>
#include <QHeaderView>
#include <QInputDialog>
#include <QDate>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

//1. BASE CLASS & FORWARD DECLARATIONS
class LMSWindow;

class User {
protected:
    string id, name, password;
public:
    User(string i, string n, string p) : id(i), name(n), password(p) {}
    virtual ~User() {}
    bool login(string i, string p) { return id == i && password == p; }
    string getName() { return name; }
    string getID() { return id; }
    virtual string getRole() = 0;
    virtual void setupDashboard(LMSWindow* gui) = 0;
};

//2. DEFINE ROLES FIRST

class Administrator : public User {
public:
    Administrator(string i, string n, string p) : User(i, n, p) {}
    string getRole() override { return "Admin"; }
    void setupDashboard(LMSWindow* gui) override;
};

class Instructor : public User {
public:
    Instructor(string i, string n, string p) : User(i, n, p) {}
    string getRole() override { return "Teacher"; }
    void setupDashboard(LMSWindow* gui) override;
};

class Learner : public User {
public:
    Learner(string i, string n, string p) : User(i, n, p) {}
    string getRole() override { return "Student"; }
    void setupDashboard(LMSWindow* gui) override;
};

// --- 3. MAIN WINDOW ENGINE ---
class LMSWindow : public QMainWindow {
    Q_OBJECT
public:
    vector<User*> users;
    QVBoxLayout* rootLayout;
    QStackedWidget* contentStack;

    LMSWindow() {
        users.push_back(new Administrator("admin", "Head Admin", "123"));
        users.push_back(new Instructor("t1", "Dr. Ahmed", "123"));
        users.push_back(new Learner("s1", "Ali Khan", "123"));

        setStyleSheet(R"(
            QMainWindow { background: #0F172A; }
            #sidebar { background: #1E293B; min-width: 220px; }
            #glassCard { background: white; border-radius: 15px; }
            #headerText { font-size: 22px; font-weight: bold; color: #1E293B; }
            #primaryBtn { background: #3B82F6; color: white; padding: 12px; border-radius: 8px; font-weight: bold; border: none; }
            #navBtn { background: transparent; color: #94A3B8; text-align: left; padding: 15px; border: none; font-weight: bold; font-size: 13px; }
            #navBtn:hover { background: #334155; color: white; }
            #dangerBtn { background: #EF4444; color: white; padding: 10px; border-radius: 5px; font-weight: bold; border: none; }
            QTableWidget { color: black; background: white; gridline-color: #E2E8F0; border: none; }
            QHeaderView::section { background: #F8FAFC; padding: 10px; font-weight: bold; border: none; }
        )");

        QWidget* central = new QWidget(this);
        setCentralWidget(central);
        rootLayout = new QVBoxLayout(central);
        rootLayout->setContentsMargins(0,0,0,0);
        showLogin();
    }

    void showLogin() {
        clearScreen();
        QWidget* p = new QWidget(); QVBoxLayout* lay = new QVBoxLayout(p); lay->setAlignment(Qt::AlignCenter);
        QFrame* card = new QFrame(); card->setObjectName("glassCard"); card->setFixedSize(380, 450);
        QVBoxLayout* cL = new QVBoxLayout(card); cL->setContentsMargins(30,30,30,30);

        QLabel* title = new QLabel("LMS PORTAL"); title->setObjectName("headerText"); title->setAlignment(Qt::AlignCenter);
        QLineEdit* idIn = new QLineEdit(); idIn->setPlaceholderText("Enter ID");
        QLineEdit* pwIn = new QLineEdit(); pwIn->setPlaceholderText("Password");
        pwIn->setEchoMode(QLineEdit::Password);
        QPushButton* btn = new QPushButton("Login"); btn->setObjectName("primaryBtn");

        cL->addWidget(title); cL->addSpacing(20);
        cL->addWidget(idIn); cL->addWidget(pwIn); cL->addSpacing(20);
        cL->addWidget(btn); lay->addWidget(card); rootLayout->addWidget(p);
        connect(btn, &QPushButton::clicked, [=]() {
            for (auto u : users) {
                if (u->login(idIn->text().toStdString(), pwIn->text().toStdString())) {
                    u->setupDashboard(this); return;
                }
            }
            QMessageBox::warning(this, "Denied", "User not found.");
        });
    }

    void clearScreen() {
        QLayoutItem* item;
        while ((item = rootLayout->takeAt(0)) != nullptr) {
            if (item->widget()) item->widget()->deleteLater();
            delete item;
        }
    }

    void addNav(QVBoxLayout* lay, QString txt, int idx) {
        QPushButton* b = new QPushButton(txt); b->setObjectName("navBtn");
        lay->addWidget(b);
        connect(b, &QPushButton::clicked, [=](){ contentStack->setCurrentIndex(idx); });
    }
};

//4. DETAILED AUTHORITY IMPLEMENTATION

void Administrator::setupDashboard(LMSWindow* gui) {
    gui->clearScreen();
    QWidget* page = new QWidget(); QHBoxLayout* layout = new QHBoxLayout(page); layout->setContentsMargins(0,0,0,0);
    QWidget* side = new QWidget(); side->setObjectName("sidebar");
    QVBoxLayout* sL = new QVBoxLayout(side);

    gui->contentStack = new QStackedWidget();
    gui->addNav(sL, "👥 User Directory", 0);
    gui->addNav(sL, "➕ Register User", 1);
    sL->addStretch();
    QPushButton* lo = new QPushButton("Logout"); lo->setObjectName("dangerBtn");
    sL->addWidget(lo); gui->connect(lo, &QPushButton::clicked, gui, &LMSWindow::showLogin);

    // Page 0: Directory
    QTableWidget* t = new QTableWidget(0,3); t->setHorizontalHeaderLabels({"ID", "Name", "Role"});
    t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    auto ref = [=]() {
        t->setRowCount(0);
        for(auto u : gui->users) {
            int r = t->rowCount(); t->insertRow(r);
            t->setItem(r,0, new QTableWidgetItem(QString::fromStdString(u->getID())));
            t->setItem(r,1, new QTableWidgetItem(QString::fromStdString(u->getName())));
            t->setItem(r,2, new QTableWidgetItem(QString::fromStdString(u->getRole())));
        }
    }; ref();
    gui->contentStack->addWidget(t);

    // Page 1: Admin Authority (Add Teachers/Students)
    QWidget* p1 = new QWidget(); QVBoxLayout* l1 = new QVBoxLayout(p1);
    QPushButton* addB = new QPushButton("Open Registration Wizard"); addB->setObjectName("primaryBtn");
    l1->addWidget(new QLabel("Register System Participants")); l1->addWidget(addB); l1->addStretch();
    gui->connect(addB, &QPushButton::clicked, [=](){
        QStringList roles = {"Teacher", "Student"}; bool ok;
        QString role = QInputDialog::getItem(gui, "Admin", "User Role:", roles, 0, false, &ok);
        if(ok) {
            string id = QInputDialog::getText(gui, "Admin", "Set ID:").toStdString();
            string nm = QInputDialog::getText(gui, "Admin", "Full Name:").toStdString();
            string ps = QInputDialog::getText(gui, "Admin", "Set Password:").toStdString();
            if(role == "Teacher") gui->users.push_back(new Instructor(id, nm, ps));
            else gui->users.push_back(new Learner(id, nm, ps));
            ref(); gui->contentStack->setCurrentIndex(0);
            QMessageBox::information(gui, "Admin", "User Registered Successfully!");
        }
    });
    gui->contentStack->addWidget(p1);

    layout->addWidget(side); layout->addWidget(gui->contentStack); gui->rootLayout->addWidget(page);
}

void Instructor::setupDashboard(LMSWindow* gui) {
    gui->clearScreen();
    QWidget* page = new QWidget(); QHBoxLayout* layout = new QHBoxLayout(page); layout->setContentsMargins(0,0,0,0);
    QWidget* side = new QWidget(); side->setObjectName("sidebar");
    QVBoxLayout* sL = new QVBoxLayout(side);

    gui->contentStack = new QStackedWidget();
    gui->addNav(sL, "📝 Post Assignment", 0);
    gui->addNav(sL, "✅ Attendance", 1);
    gui->addNav(sL, "🎯 Mark Grade", 2);
    sL->addStretch();
    QPushButton* lo = new QPushButton("Logout"); lo->setObjectName("dangerBtn");
    sL->addWidget(lo); gui->connect(lo, &QPushButton::clicked, gui, &LMSWindow::showLogin);

    // Page 0: Assignment
    QWidget* p0 = new QWidget(); QVBoxLayout* l0 = new QVBoxLayout(p0);
    QPushButton* asB = new QPushButton("Publish Assignment"); asB->setObjectName("primaryBtn");
    l0->addWidget(asB);
    gui->connect(asB, &QPushButton::clicked, [=](){
        string t = QInputDialog::getText(gui, "Teacher", "Assignment Title:").toStdString();
        ofstream f("assignments.txt", ios::app); f << t << "|Active" << endl; f.close();
        QMessageBox::information(gui, "Success", "Posted to students.");
    });
    gui->contentStack->addWidget(p0);

    // Page 1: Attendance
    QWidget* p1 = new QWidget(); QVBoxLayout* l1 = new QVBoxLayout(p1);
    QPushButton* atB = new QPushButton("Save Attendance Record"); atB->setObjectName("primaryBtn");
    l1->addWidget(atB);
    gui->connect(atB, &QPushButton::clicked, [=](){
        string sid = QInputDialog::getText(gui, "Roll Call", "Student ID:").toStdString();
        ofstream f("attendance.txt", ios::app); f << sid << "|Present|" << QDate::currentDate().toString().toStdString() << endl; f.close();
        QMessageBox::information(gui, "Success", "Attendance Saved.");
    });
    gui->contentStack->addWidget(p1);

    // Page 2: Marking (New Authority)
    QWidget* p2 = new QWidget(); QVBoxLayout* l2 = new QVBoxLayout(p2);
    QPushButton* grB = new QPushButton("Enter Student Grade"); grB->setObjectName("primaryBtn");
    l2->addWidget(grB);
    gui->connect(grB, &QPushButton::clicked, [=](){
        string sid = QInputDialog::getText(gui, "Grading", "Student ID:").toStdString();
        string marks = QInputDialog::getText(gui, "Grading", "Marks/GPA:").toStdString();
        ofstream f("grades.txt", ios::app); f << sid << "|" << marks << endl; f.close();
        QMessageBox::information(gui, "LMS", "Grade Assigned to student " + QString::fromStdString(sid));
    });
    gui->contentStack->addWidget(p2);

    layout->addWidget(side); layout->addWidget(gui->contentStack); gui->rootLayout->addWidget(page);
}

void Learner::setupDashboard(LMSWindow* gui) {
    gui->clearScreen();
    QWidget* page = new QWidget(); QHBoxLayout* layout = new QHBoxLayout(page); layout->setContentsMargins(0,0,0,0);
    QWidget* side = new QWidget(); side->setObjectName("sidebar");
    QVBoxLayout* sL = new QVBoxLayout(side);

    gui->contentStack = new QStackedWidget();
    gui->addNav(sL, "📚 My Tasks", 0);
    gui->addNav(sL, "📊 Gradebook", 1);
    gui->addNav(sL, "📅 My Attendance", 2);
    sL->addStretch();
    QPushButton* lo = new QPushButton("Logout"); lo->setObjectName("dangerBtn");
    sL->addWidget(lo); gui->connect(lo, &QPushButton::clicked, gui, &LMSWindow::showLogin);

    // Page 0: Tasks
    QWidget* p0 = new QWidget(); QVBoxLayout* l0 = new QVBoxLayout(p0);
    QTableWidget* at = new QTableWidget(0,1); at->setHorizontalHeaderLabels({"Current Assignments"});
    at->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ifstream f("assignments.txt"); string ln;
    while(getline(f, ln)) {
        int r = at->rowCount(); at->insertRow(r);
        at->setItem(r,0, new QTableWidgetItem(QString::fromStdString(ln)));
    }
    QPushButton* subB = new QPushButton("Submit Selected Task"); subB->setObjectName("primaryBtn");
    l0->addWidget(at); l0->addWidget(subB);
    gui->connect(subB, &QPushButton::clicked, [=](){ QMessageBox::information(gui, "LMS", "Task Submitted!"); });
    gui->contentStack->addWidget(p0);

    // Page 1: My Gradebook (New Feature)
    QTableWidget* gt = new QTableWidget(0,1); gt->setHorizontalHeaderLabels({"My Verified Grades"});
    gt->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ifstream gf("grades.txt");
    while(getline(gf, ln)) {
        stringstream ss(ln); string sid, g;
        if(getline(ss, sid, '|') && getline(ss, g, '|')) {
            if(sid == getID()) {
                int r = gt->rowCount(); gt->insertRow(r);
                gt->setItem(r,0, new QTableWidgetItem(QString::fromStdString(g)));
            }
        }
    }
    gui->contentStack->addWidget(gt);

    // Page 2: Attendance
    QTableWidget* attT = new QTableWidget(0,2); attT->setHorizontalHeaderLabels({"Status", "Date"});
    attT->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ifstream af("attendance.txt");
    while(getline(af, ln)) {
        stringstream ss(ln); string sid, s, d;
        if(getline(ss, sid, '|') && getline(ss, s, '|') && getline(ss, d, '|')) {
            if(sid == getID()) {
                int r = attT->rowCount(); attT->insertRow(r);
                attT->setItem(r,0, new QTableWidgetItem(QString::fromStdString(s)));
                attT->setItem(r,1, new QTableWidgetItem(QString::fromStdString(d)));
            }
        }
    }
    gui->contentStack->addWidget(attT);

    layout->addWidget(side); layout->addWidget(gui->contentStack); gui->rootLayout->addWidget(page);
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    LMSWindow w; w.setWindowTitle("University Learning Portal"); w.resize(1100, 750); w.show();
    return app.exec();
}
#include "main.moc"
